﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            CallTelService();
            CallOrderService();
            Console.Read();
        }

        static void CallTelService()
        {
            IMp3 mp3 = new Mp3Client(new NetTcpBinding(), new EndpointAddress("net.tcp://127.0.0.1:1236/mp3"));
            mp3.PlaySound("12");

            IRecorder recorder = new RecorderClient(new NetTcpBinding(), new EndpointAddress("net.tcp://127.0.0.1:1236/recorder"));
            recorder.Record();

            ITelephone tel = new TelephoneClient(new NetTcpBinding(), new EndpointAddress("net.tcp://127.0.0.1:1236/tel"));
            tel.Call("124");
            tel.Pickup("124");
            tel.ReceiveMessage("124");
            tel.SendMessage("124");
            tel.Record();
            tel.PlaySound("2");
        }

        static void CallOrderService()
        {
            IOrderManager orderService = new OrderManagerClient(new NetTcpBinding(), new EndpointAddress("net.tcp://127.0.0.1:1237/order"));
            Contracts.Order order = new Contracts.Order();
            orderService.Process(order);
            Contracts.OrderDetail orderDetail = new Contracts.OrderDetail();
            orderService.Process(orderDetail);
        }
    }
}
