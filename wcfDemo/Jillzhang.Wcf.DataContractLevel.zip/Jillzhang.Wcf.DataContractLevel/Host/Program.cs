﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;

namespace Host
{
    class Program
    {
        static void Main(string[] args)
        {
            HostTelService();
            HostOrderService();
            Console.Read();         
        }

        static void HostTelService()
        {
            Uri baseAddress = new Uri("net.tcp://127.0.0.1:1236");
            ServiceHost host = new ServiceHost(typeof(Services.Telephone), baseAddress);
            host.AddServiceEndpoint(typeof(Contracts.IMp3), new NetTcpBinding(), "mp3");
            host.AddServiceEndpoint(typeof(Contracts.IRecorder), new NetTcpBinding(), "recorder");
            host.AddServiceEndpoint(typeof(Contracts.ITelephone), new NetTcpBinding(), "tel");
            ServiceMetadataBehavior metaBehavior = host.Description.Behaviors.Find<ServiceMetadataBehavior>();
            if (metaBehavior == null)
            {
                metaBehavior = new ServiceMetadataBehavior();
                host.Description.Behaviors.Add(metaBehavior);
            }
            BindingElement bindingElement = new TcpTransportBindingElement();
            CustomBinding metaBind = new CustomBinding(bindingElement);
            host.AddServiceEndpoint(typeof(IMetadataExchange), metaBind, "MEX");
            host.Open();
            Console.WriteLine("tel service is running...");          
        }
        static void HostOrderService()
        {
            Uri baseAddress = new Uri("net.tcp://127.0.0.1:1237");
            ServiceHost host = new ServiceHost(typeof(Services.OrderManager), baseAddress);
            host.AddServiceEndpoint(typeof(Contracts.IOrderManager), new NetTcpBinding(), "order");        
            ServiceMetadataBehavior metaBehavior = host.Description.Behaviors.Find<ServiceMetadataBehavior>();
            if (metaBehavior == null)
            {
                metaBehavior = new ServiceMetadataBehavior();
                host.Description.Behaviors.Add(metaBehavior);
            }
            BindingElement bindingElement = new TcpTransportBindingElement();
            CustomBinding metaBind = new CustomBinding(bindingElement);
            host.AddServiceEndpoint(typeof(IMetadataExchange), metaBind, "MEX");
            host.Open();
            Console.WriteLine("order service is running...");
        }
    }
}
