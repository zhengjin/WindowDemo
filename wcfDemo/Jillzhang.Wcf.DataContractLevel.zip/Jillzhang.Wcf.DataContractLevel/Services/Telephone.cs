﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  8d5dfb12-6bc0-4a36-b81f-a3364c4421dc
//        guid2:  9f8cc9af-72e5-47ec-9d95-52bad3f996e6
//        guid3:  c32d4c92-8efe-45d4-83e8-ac5458efb55e
//        guid4:  1a3e1f2f-3832-4068-8d6d-c2a54d73f855
//        guid5:  54736603-6c3e-4a2a-baf2-350411cfbc48
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: Telephone
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Services
//        文件名:              Telephone
//        当前系统时间:      4/25/2008 9:07:52 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/25/2008 9:07:52 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Services
{
    using log = System.Console;
    public class Telephone:Contracts.ITelephone
    {
        public void Call(string to)
        {
            log.WriteLine("telephone is calling...");
        }
        public void Pickup(string from)
        {
            log.WriteLine("telphone is pickuping....");
        }
        public void ReceiveMessage(string from)
        {
            log.WriteLine("telephone is receiving private message");
        }
        public void SendMessage(string to)
        {
            log.WriteLine("telephone is sending private message");
        }
        public void PlaySound(string soundFile)
        {
            log.WriteLine("telephone is playing...");
        }
        public void Record()
        {
            log.WriteLine("telephone is recording...");
        } 
    }
}
