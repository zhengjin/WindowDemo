﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  2fc68265-c30d-4b49-8fc4-1a83815555b4
//        guid2:  31534e8d-9475-4486-9f7a-435057708b6a
//        guid3:  589ea7c7-a883-457a-a769-28789732f5d6
//        guid4:  be91a08a-c0dd-481b-a3b8-4033e35d2038
//        guid5:  97d2738e-c669-4350-be8c-64d418a765f4
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: OrderManager
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Services
//        文件名:              OrderManager
//        当前系统时间:      4/26/2008 1:27:55 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/26/2008 1:27:55 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Contracts;

namespace Services
{
    using log = System.Console;
    public class OrderManager:IOrderManager
    {

        public void Process(Order order)
        {
            log.WriteLine("OrderManager is processing order....");
        }
        
    }
}
