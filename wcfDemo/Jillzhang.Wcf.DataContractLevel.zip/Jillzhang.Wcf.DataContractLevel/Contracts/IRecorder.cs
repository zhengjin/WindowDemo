﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  00c06112-3bb5-459a-be9a-1cb56035b810
//        guid2:  6f6683b7-4e02-4307-b99a-6757a6828fdd
//        guid3:  c0af335e-5d7a-4710-8a16-0faa22270848
//        guid4:  ad4f431c-a255-4bc1-9abb-777632822baf
//        guid5:  15b3835f-fe2c-498d-aa21-37e7a46bcf80
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: IRecorder
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Contracts
//        文件名:              IRecorder
//        当前系统时间:      4/25/2008 9:33:17 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/25/2008 9:33:17 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
    [ServiceContract]
    public interface  IRecorder
    {
        [OperationContract]
        void Record();
    }
}
