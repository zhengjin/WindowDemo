﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  00740e57-64bd-4a0f-8313-5709e1225b25
//        guid2:  9f528925-79a9-4a63-83cd-6cfdf78fb9f4
//        guid3:  931104b4-181e-4d95-a940-98b81d7b44ed
//        guid4:  6592334d-2d86-4956-b340-9dea1345959d
//        guid5:  68893ea0-4212-4bd7-a87c-7dcdaa5aa39a
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: IOrderManager
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Contracts
//        文件名:              IOrderManager
//        当前系统时间:      4/26/2008 1:26:24 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/26/2008 1:26:24 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
    [ServiceContract]
    public interface IOrderManager
    {
        [OperationContract]
        void Process(Order order);    
    }
}
