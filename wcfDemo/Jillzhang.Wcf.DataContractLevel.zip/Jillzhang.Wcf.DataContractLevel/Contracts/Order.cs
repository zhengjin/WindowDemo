﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  27c81fad-d9f0-4dcc-91c0-8cea16a9476f
//        guid2:  17399e5c-e22d-420e-bdc5-508a939628b2
//        guid3:  c02a895a-ed32-4b7b-bf76-409a72959dee
//        guid4:  b96c09b4-d132-45c2-b48f-59fde115dd08
//        guid5:  6d6d1a1f-35b2-41bf-8c80-d91679a40353
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: IUser
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Contracts
//        文件名:              IUser
//        当前系统时间:      4/26/2008 1:22:51 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/26/2008 1:22:51 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Contracts
{
    [DataContract]
    public class Order:IExtensibleDataObject
    {
        private System.Runtime.Serialization.ExtensionDataObject extensionDataField;
        public System.Runtime.Serialization.ExtensionDataObject ExtensionData
        {
            get
            {
                return this.extensionDataField;
            }
            set
            {
                this.extensionDataField = value;
            }
        }
        [DataMember]
        public string OrderName
        {
            get;
            set;
        }     
    }
}
