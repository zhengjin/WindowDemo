﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  1caa0ed6-7e51-4d55-9e96-2bf3378426d5
//        guid2:  5a7bc6f1-b811-4878-a8d4-85056a5bc046
//        guid3:  5e5c37c7-d52d-4509-a42d-b9287103b95b
//        guid4:  224d0eac-4fbd-430e-9a9e-f819317aff82
//        guid5:  7959dcb0-2dd7-4fd4-b9be-d38a1d69be72
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: IRadiogram
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Contracts
//        文件名:              IRadiogram
//        当前系统时间:      4/25/2008 8:59:24 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/25/2008 8:59:24 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
    [ServiceContract]
    public interface IMp3
    {
        [OperationContract]
        void PlaySound(string soundFile);
    }
}
