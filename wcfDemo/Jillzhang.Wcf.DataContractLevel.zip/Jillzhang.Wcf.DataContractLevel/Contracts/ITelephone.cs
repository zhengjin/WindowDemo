﻿//======================================================================
//
//        Copyright (C) 2007-2008 Jillzhang
//        All rights reserved
//        guid1:  ebb30fbc-7469-4694-832a-51cdd6029b70
//        guid2:  facc9330-d6b6-4427-8bb6-06b76039c3b4
//        guid3:  face5bac-3503-4f11-946a-cfc7783ec8c7
//        guid4:  a995623f-8ec4-42b7-bf26-2c874e882e89
//        guid5:  71c52809-e890-4b2e-8243-0ed27dffbfe4
//        CLR版本:            2.0.50727.1433
//        新建项输入的名称: ITelephone
//        机器名称:            JILLZHANG-PC
//        注册组织名:         
//        命名空间名称:      Contracts
//        文件名:              ITelephone
//        当前系统时间:      4/25/2008 9:00:36 PM
//        用户所在的域:      jillzhang-PC
//        当前登录用户名:   jillzhang
//        创建年份:           2008
//
//        created by Jillzhang at  4/25/2008 9:00:36 PM
//        http://jillzhang.cnblogs.com
//
//======================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Contracts
{
    [ServiceContract]
    public interface  ITelephone:IMp3,IRecorder
    {
        [OperationContract]
        void Call(string to);
        [OperationContract]
        void Pickup(string from);
        [OperationContract]
        void ReceiveMessage(string from);
        [OperationContract]
        void SendMessage(string to);     
    }
}
